﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lb2Q4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double num = 4;
            if (num%2 == 0)
            {
                Console.WriteLine("the number is an even number");

            }
            else
            {
                Console.WriteLine("the number is an odd number");
           
            }
            Console.ReadLine();
        }
    }
}
