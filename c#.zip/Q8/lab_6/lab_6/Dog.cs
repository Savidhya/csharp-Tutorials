﻿using System;
namespace lab_6
{
	public class Dog : Animal
	{
		public void bark()
		{
			Console.WriteLine("I have four legs");
		}
	}
}

