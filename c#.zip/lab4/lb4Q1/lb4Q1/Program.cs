﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lb4Q1
{
    internal class Program
    {
        static void Main(string[] args)
        {
          
            {
                ConvertValues converter = new ConvertValues();
                converter.KilometerToMeter();


            }
        }
    }
}
