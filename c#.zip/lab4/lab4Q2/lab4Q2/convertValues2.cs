﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab4Q2
{
    internal class convertValues2
    {
        public class ConvertValues
        {
            public void KilometerToMeter(double kilometers)
            {
                double meters = kilometers * 1000;
                Console.WriteLine("kilometers in meters="+meters);
            }
        }
    }
}
