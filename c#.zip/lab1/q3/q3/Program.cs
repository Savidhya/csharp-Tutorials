﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace q3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double num1 = 23.43;
            double num2 = 45.22;
            double sum =num1+ num2;
            Console.WriteLine("summation of 2input values= " + sum);
            Console.ReadLine();
        }
    }
}
