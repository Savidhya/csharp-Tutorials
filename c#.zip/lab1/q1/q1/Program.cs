﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace q1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string name = "Nimal D V H";
            double batch = 22.2;
            Console.WriteLine("your name:" + name);
            Console.WriteLine("your batch:" + batch);
            Console.ReadKey();

        }
    }
}
